class PagesController < ApplicationController
	def stem

	end

	def contact

	end
end
